/* -*- mode: c; buffer-read-only: t -*- */
const char ofp_pkgdatadir[] = "/usr/local/share/openflow";
const char ofp_rundir[] = "/usr/local/var/run";
const char ofp_logdir[] = "/usr/local/var/log/openflow";
