
#ifndef __LINUX_MTD_COMPATMAC_H__
#define __LINUX_MTD_COMPATMAC_H__

/* Nothing to see here. We write 2.5-compatible code and this
   file makes it all OK in older kernels, but it's empty in _current_
   kernels. Include guard just to make GCC ignore it in future inclusions
   anyway... */

#endif /* __LINUX_MTD_COMPATMAC_H__ */
