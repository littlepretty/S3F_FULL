#ifndef _AFFS_FS_H
#define _AFFS_FS_H
/*
 * The affs filesystem constants/structures
 */
#define AFFS_SUPER_MAGIC 0xadff
#endif
